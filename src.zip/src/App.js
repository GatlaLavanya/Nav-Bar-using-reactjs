import React, { useEffect, useState } from "react";
import "./App.css";
import {Routes, Route, BrowserRouter } from 'react-router-dom';
import { Navbar } from "./Components/Navbar/Navbar.js";
import {features} from "./Pages/features.js";
import {about} from "./Pages/about.js";
import {Home} from "./Pages/Home.js";
import {products} from "./Pages/products.js";
import {contact} from "./Pages/contact.js";
function App() {
  const current_theme = localStorage.getItem("current_theme");
  const [theme, setTheme] = useState(current_theme);
  useEffect(() => {
    localStorage.setItem("current_theme", theme);
  }, [theme]);
  return (
    <BrowserRouter>
    
      <div className={`container ${theme}`}>
        <Navbar theme={theme} setTheme={setTheme} />
        <Routes>
          <Route path="/" exact component={Home} />
          <Route path="/products" component={products} />
          <Route path="/features" component={features} />
          <Route path="/about" component={about} />
          <Route path="/contact" component={contact} />
          </Routes>
      </div>
    
    </BrowserRouter>
  );
}


export default App;
