import React from 'react'

export const products = () => {
  return (
    <div><h1>Product page</h1></div>
  )
}
