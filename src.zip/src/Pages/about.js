import React from 'react'

export const about = () => {
  return (
    <div>about</div>
  )
}
