import React from 'react'

export const features = () => {
  return (
    <div><h1>features</h1></div>
  )
}
