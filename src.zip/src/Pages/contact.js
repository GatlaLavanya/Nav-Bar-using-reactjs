import React from 'react'

export const contact = () => {
  return (
    <div>contact</div>
  )
}
